// AL-SHEHAB Script
