import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:path_provider/path_provider.dart';
import 'package:printing/printing.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import 'database/app_database.dart';
import 'services/pdf_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppDatabase.instance.database;
  runApp(const AlShehabCommercialApp());
}

class AlShehabCommercialApp extends StatelessWidget {
  const AlShehabCommercialApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'الشهاب لإدارة الجرد والحسابات',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar', 'YE'),
      supportedLocales: const [Locale('ar', 'YE'), Locale('ar')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF0F766E),
          primary: const Color(0xFF0F766E),
          secondary: const Color(0xFFF59E0B),
        ),
        scaffoldBackgroundColor: const Color(0xFFF1F5F9),
        useMaterial3: true,
      ),
      home: const BranchSelectionSplash(),
    );
  }
}

class BranchSelectionSplash extends StatelessWidget {
  const BranchSelectionSplash({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFF0F172A),
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 480),
                child: Card(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const CircleAvatar(
                          radius: 34,
                          backgroundColor: Color(0xFF0F766E),
                          child: Text('ش', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: Colors.amber)),
                        ),
                        const SizedBox(height: 12),
                        const Text('الشهاب لإدارة الجرد والحسابات',
                            textAlign: TextAlign.center,
                            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 4),
                        const Text('النسخة التجارية الكاملة • يعمل دون إنترنت (ر.ي)',
                            textAlign: TextAlign.center,
                            style: TextStyle(fontSize: 12, color: Colors.grey)),
                        const SizedBox(height: 20),
                        _branchCard(context, 'branch1', 'الفرع الأول', 'جرد مستقل، مخزون، ديون، سحبيات، مصروفات وضمار مستقل', const Color(0xFF0F766E)),
                        const SizedBox(height: 12),
                        _branchCard(context, 'branch2', 'الفرع الثاني', 'جرد مستقل، مخزون، ديون، سحبيات، مصروفات وضمار مستقل', const Color(0xFF3730A3)),
                        const SizedBox(height: 12),
                        _branchCard(context, 'consolidated', 'التقرير الإجمالي للفرعين', 'عرض المركز المالي والضمار الموحد للفرعين دون دمج سجلاتهما', const Color(0xFFB45309)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _branchCard(BuildContext context, String branchId, String title, String subtitle, Color color) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        onPressed: () {
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (_) => MainShellScreen(initialBranch: branchId)),
          );
        },
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text(subtitle, style: const TextStyle(fontSize: 11, color: Colors.white70)),
          ],
        ),
      ),
    );
  }
}

class MainShellScreen extends StatefulWidget {
  final String initialBranch;
  const MainShellScreen({super.key, required this.initialBranch});

  @override
  State<MainShellScreen> createState() => _MainShellScreenState();
}

class _MainShellScreenState extends State<MainShellScreen> {
  late String activeBranch;
  int selectedNavIndex = 0;

  // Controllers for Keyboard-First Inventory Workstation
  final TextEditingController _invNameCtrl = TextEditingController();
  final TextEditingController _invPackCountCtrl = TextEditingController(text: '1');
  final TextEditingController _invSingleUnitsCtrl = TextEditingController(text: '0');
  final TextEditingController _invUnitsPerPackCtrl = TextEditingController(text: '12');
  final TextEditingController _invPackTypeCtrl = TextEditingController(text: 'كرتون');
  final TextEditingController _invPackPriceCtrl = TextEditingController(text: '0');
  final FocusNode _nameFocusNode = FocusNode();
  final FocusNode _qtyFocusNode = FocusNode();
  String _selectedPriceStatus = 'needs_review'; // الافتراضي: للمراجعة

  Map<String, dynamic> _metrics = {};
  List<Map<String, dynamic>> _products = [];
  List<Map<String, dynamic>> _inventories = [];
  int? _activeInventoryId;
  List<Map<String, dynamic>> _activeInventoryItems = [];
  List<Map<String, dynamic>> _unpricedItems = [];
  List<Map<String, dynamic>> _customers = [];
  List<Map<String, dynamic>> _suppliers = [];
  List<Map<String, dynamic>> _withdrawals = [];
  List<Map<String, dynamic>> _expenses = [];
  List<Map<String, dynamic>> _auditLogs = [];

  static const List<String> navTitles = [
    '1. الرئيسية',
    '2. الجرد السريع',
    '3. قاعدة الأصناف',
    '4. الأصناف غير المسعرة',
    '5. ديون العملاء',
    '6. ديون المتجر للموردين',
    '7. السحبيات',
    '8. المصروفات التشغيلية',
    '9. التقارير والضمار والمقارنة',
    '10. الإعدادات والنسخ الاحتياطي',
  ];

  static const List<String> expenseCategories = [
    'الإيجار',
    'الكهرباء',
    'المياه',
    'أجور العمال',
    'النقل',
    'الصيانة',
    'مصروفات أخرى'
  ];

  @override
  void initState() {
    super.initState();
    activeBranch = widget.initialBranch;
    _reloadAllData();
  }

  String get _targetBranch => activeBranch == 'consolidated' ? 'branch1' : activeBranch;

  Future<void> _reloadAllData() async {
    final db = await AppDatabase.instance.database;
    final String bId = _targetBranch;

    final prods = await db.query('products', orderBy: 'id DESC');
    final invs = await db.query('inventories', where: 'branch_id = ?', whereArgs: [bId], orderBy: 'id DESC');

    int? currentInvId = _activeInventoryId;
    if (invs.isNotEmpty && (currentInvId == null || !invs.any((x) => x['id'] == currentInvId))) {
      currentInvId = invs.first['id'] as int;
    } else if (invs.isEmpty) {
      currentInvId = null;
    }

    List<Map<String, dynamic>> invItems = [];
    if (currentInvId != null) {
      invItems = await db.query('inventory_items', where: 'inventory_id = ?', whereArgs: [currentInvId]);
    }

    final unpriced = await db.rawQuery('''
      SELECT ii.*, i.name as inventory_name, i.branch_id
      FROM inventory_items ii
      JOIN inventories i ON i.id = ii.inventory_id
      WHERE ii.price_status != 'confirmed' AND i.branch_id = ?
    ''', [bId]);

    final custs = await db.rawQuery('''
      SELECT c.*,
        COALESCE((SELECT SUM(amount) FROM customer_transactions WHERE customer_id = c.id AND tx_type = 'debt'), 0) as total_debt,
        COALESCE((SELECT SUM(amount) FROM customer_transactions WHERE customer_id = c.id AND tx_type = 'payment'), 0) as total_paid
      FROM customers c WHERE c.branch_id = ?
    ''', [bId]);

    final sups = await db.rawQuery('''
      SELECT s.*,
        COALESCE((SELECT SUM(amount) FROM supplier_transactions WHERE supplier_id = s.id AND tx_type = 'debt'), 0) as total_debt,
        COALESCE((SELECT SUM(amount) FROM supplier_transactions WHERE supplier_id = s.id AND tx_type = 'payment'), 0) as total_paid
      FROM suppliers s WHERE s.branch_id = ?
    ''', [bId]);

    final withs = await db.query('withdrawals', where: 'branch_id = ?', whereArgs: [bId], orderBy: 'id DESC');
    final exps = await db.query('expenses', where: 'branch_id = ?', whereArgs: [bId], orderBy: 'id DESC');
    final logs = await db.query('audit_logs', orderBy: 'id DESC', limit: 100);

    double invVal = 0;
    for (final it in invItems) {
      invVal += AppDatabase.calculateRowMetrics(it)['total_value'] ?? 0;
    }

    final double custDebts = custs.fold(0.0, (s, c) => s + (((c['total_debt'] as num?)?.toDouble() ?? 0) - ((c['total_paid'] as num?)?.toDouble() ?? 0)));
    final double supDebts = sups.fold(0.0, (s, x) => s + (((x['total_debt'] as num?)?.toDouble() ?? 0) - ((x['total_paid'] as num?)?.toDouble() ?? 0)));
    final double wTotal = withs.fold(0.0, (s, x) => s + ((x['amount'] as num?)?.toDouble() ?? 0.0));
    final double eTotal = exps.fold(0.0, (s, x) => s + ((x['amount'] as num?)?.toDouble() ?? 0.0));

    final bRows = await db.query('branches', where: 'id = ?', whereArgs: [bId]);
    final double cash = bRows.isNotEmpty ? ((bRows.first['registered_cash'] as num?)?.toDouble() ?? 0.0) : 0.0;
    final double otherLiab = bRows.isNotEmpty ? ((bRows.first['other_liabilities'] as num?)?.toDouble() ?? 0.0) : 0.0;
    final double openCap = bRows.isNotEmpty ? ((bRows.first['opening_capital'] as num?)?.toDouble() ?? 0.0) : 0.0;

    final double totalAdditions = invVal + cash + custDebts;
    final double totalDeductions = supDebts + otherLiab + wTotal + eTotal;
    final double netDhamar = totalAdditions - totalDeductions;

    if (!mounted) return;
    setState(() {
      _products = prods;
      _inventories = invs;
      _activeInventoryId = currentInvId;
      _activeInventoryItems = invItems;
      _unpricedItems = unpriced;
      _customers = custs;
      _suppliers = sups;
      _withdrawals = withs;
      _expenses = exps;
      _auditLogs = logs;
      _metrics = {
        'inventory_value': invVal,
        'customer_debts': custDebts,
        'supplier_debts': supDebts,
        'registered_cash': cash,
        'other_liabilities': otherLiab,
        'opening_capital': openCap,
        'withdrawals_total': wTotal,
        'expenses_total': eTotal,
        'total_additions': totalAdditions,
        'total_deductions': totalDeductions,
        'net_dhamar': netDhamar,
      };
    });
  }

  Future<void> _quickAddInventoryItem() async {
    final name = _invNameCtrl.text.trim();
    if (name.isEmpty) return;
    final db = await AppDatabase.instance.database;
    final String bId = _targetBranch;

    int? invId = _activeInventoryId;
    if (invId == null) {
      invId = await db.insert('inventories', {
        'branch_id': bId,
        'name': 'جرد ${DateTime.now().toIso8601String().substring(0, 10)}',
        'inv_date': DateTime.now().toIso8601String().substring(0, 10),
        'status': 'open',
      });
      _activeInventoryId = invId;
    }

    final double packCount = double.tryParse(_invPackCountCtrl.text) ?? 1;
    final double singleUnits = double.tryParse(_invSingleUnitsCtrl.text) ?? 0;
    final int unitsPerPack = int.tryParse(_invUnitsPerPackCtrl.text) ?? 12;
    final double packPrice = double.tryParse(_invPackPriceCtrl.text) ?? 0;
    final double unitPrice = unitsPerPack > 0 ? (packPrice / unitsPerPack) : 0;

    // دمج الكميات تلقائياً إذا كان الصنف مسجلاً في نفس الجرد
    final existing = await db.query('inventory_items',
        where: 'inventory_id = ? AND product_name = ?', whereArgs: [invId, name]);

    if (existing.isNotEmpty) {
      final row = existing.first;
      final newPackCount = ((row['pack_count'] as num?)?.toDouble() ?? 0) + packCount;
      final newSingle = ((row['single_units'] as num?)?.toDouble() ?? 0) + singleUnits;
      await db.update(
        'inventory_items',
        {
          'pack_count': newPackCount,
          'single_units': newSingle,
          if (packPrice > 0) 'pack_buy_price': packPrice,
          if (unitPrice > 0) 'unit_buy_price': unitPrice,
        },
        where: 'id = ?',
        whereArgs: [row['id']],
      );
    } else {
      await db.insert('inventory_items', {
        'inventory_id': invId,
        'product_id': 0,
        'product_name': name,
        'barcode': '',
        'pack_type': _invPackTypeCtrl.text.trim().isEmpty ? 'كرتون' : _invPackTypeCtrl.text.trim(),
        'pack_count': packCount,
        'single_units': singleUnits,
        'units_per_pack': unitsPerPack,
        'pricing_basis': 'pack',
        'unit_buy_price': unitPrice,
        'pack_buy_price': packPrice,
        'price_status': _selectedPriceStatus, // افتراضياً للمراجعة
      });
    }

    await AppDatabase.instance.logAction(bId, 'إضافة صنف', 'إدخال $name بكمية $packCount في الجرد');
    _invNameCtrl.clear();
    _invPackCountCtrl.text = '1';
    _invSingleUnitsCtrl.text = '0';
    _selectedPriceStatus = 'needs_review';
    await _reloadAllData();
    _nameFocusNode.requestFocus();
  }

  Future<void> _exportCurrentInventoryPdf() async {
    if (_activeInventoryId == null) return;
    final font = await PdfGoogleFonts.cairoRegular();
    final pdfBytes = await PdfExportService.buildInventoryAndDhamarPdf(
      branchName: _targetBranch == 'branch1' ? 'الفرع الأول' : 'الفرع الثاني',
      inventoryName: 'تقرير الجرد وحساب الضمار الشامل',
      inventoryDate: DateTime.now().toIso8601String().substring(0, 10),
      rawItems: _activeInventoryItems,
      sortOrder: InventorySortOrder.byEntryOrder,
      filterScope: InventoryFilterScope.fullInventory,
      itemsPerPage: 40,
      includeDhamarAppendix: true,
      dhamarData: _metrics,
      arabicFont: font,
    );
    await Printing.layoutPdf(onLayout: (_) async => pdfBytes);
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: const Color(0xFF0F172A),
          foregroundColor: Colors.white,
          title: Text(navTitles[selectedNavIndex], style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
          actions: [
            DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                dropdownColor: const Color(0xFF1E293B),
                value: activeBranch,
                style: const TextStyle(color: Colors.amber, fontWeight: FontWeight.bold, fontSize: 12),
                items: const [
                  DropdownMenuItem(value: 'branch1', child: Text('الفرع الأول')),
                  DropdownMenuItem(value: 'branch2', child: Text('الفرع الثاني')),
                  DropdownMenuItem(value: 'consolidated', child: Text('التقرير الإجمالي')),
                ],
                onChanged: (v) {
                  if (v != null) {
                    setState(() => activeBranch = v);
                    _reloadAllData();
                  }
                },
              ),
            ),
            IconButton(
              icon: const Icon(Icons.picture_as_pdf, color: Colors.amber),
              tooltip: 'تصدير PDF + الضمار',
              onPressed: _exportCurrentInventoryPdf,
            ),
          ],
        ),
        drawer: Drawer(
          child: Column(
            children: [
              const DrawerHeader(
                decoration: BoxDecoration(color: Color(0xFF0F172A)),
                child: Center(
                  child: Text('الشهاب لإدارة الجرد والحسابات\nAL-SHEHAB Commercial',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.amber, fontSize: 16, fontWeight: FontWeight.bold)),
                ),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: navTitles.length,
                  itemBuilder: (ctx, i) => ListTile(
                    selected: selectedNavIndex == i,
                    title: Text(navTitles[i], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                    onTap: () {
                      setState(() => selectedNavIndex = i);
                      Navigator.pop(context);
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
        body: _buildScreenByIndex(selectedNavIndex),
        bottomNavigationBar: NavigationBar(
          selectedIndex: selectedNavIndex < 5 ? selectedNavIndex : 0,
          onDestinationSelected: (idx) => setState(() => selectedNavIndex = idx),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.dashboard), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.inventory_2), label: 'الجرد'),
            NavigationDestination(icon: Icon(Icons.category), label: 'الأصناف'),
            NavigationDestination(icon: Icon(Icons.price_check), label: 'للمراجعة'),
            NavigationDestination(icon: Icon(Icons.account_balance_wallet), label: 'الديون'),
          ],
        ),
      ),
    );
  }

  Widget _buildScreenByIndex(int index) {
    switch (index) {
      case 0:
        return _buildDashboardView();
      case 1:
        return _buildFastInventoryWorkstation();
      case 2:
        return _buildProductsCatalogView();
      case 3:
        return _buildUnpricedReviewView();
      case 4:
        return _buildPartiesDebtView(isCustomer: true);
      case 5:
        return _buildPartiesDebtView(isCustomer: false);
      case 6:
        return _buildWithdrawalsView();
      case 7:
        return _buildExpensesView();
      case 8:
        return _buildDhamarAndReportsView();
      case 9:
        return _buildSettingsAndBackupView();
      default:
        return _buildDashboardView();
    }
  }

  // 1. الرئيسية
  Widget _buildDashboardView() {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        Card(
          color: const Color(0xFF0F172A),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('صافي الضمار الموجود حالياً (بعد كل الإضافات والخصميات)',
                    style: TextStyle(color: Colors.white70, fontSize: 12)),
                const SizedBox(height: 6),
                Text('${(_metrics['net_dhamar'] ?? 0).toStringAsFixed(0)} ر.ي',
                    style: const TextStyle(color: Colors.amberAccent, fontSize: 24, fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                Text('إجمالي الإضافات: ${(_metrics['total_additions'] ?? 0).toStringAsFixed(0)} ر.ي | الخصميات: ${(_metrics['total_deductions'] ?? 0).toStringAsFixed(0)} ر.ي',
                    style: const TextStyle(color: Colors.white60, fontSize: 11)),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          childAspectRatio: 1.65,
          mainAxisSpacing: 8,
          crossAxisSpacing: 8,
          children: [
            _metricTile('قيمة البضاعة بالجرد', '${(_metrics['inventory_value'] ?? 0).toStringAsFixed(0)} ر.ي', Colors.teal),
            _metricTile('ديون العملاء (لنا)', '${(_metrics['customer_debts'] ?? 0).toStringAsFixed(0)} ر.ي', Colors.green.shade700),
            _metricTile('ديون الموردين (علينا)', '${(_metrics['supplier_debts'] ?? 0).toStringAsFixed(0)} ر.ي', Colors.red.shade700),
            _metricTile('أصناف قيد المراجعة', '${_unpricedItems.length} صنف', Colors.orange.shade800),
            _metricTile('إجمالي السحبيات', '${(_metrics['withdrawals_total'] ?? 0).toStringAsFixed(0)} ر.ي', Colors.brown),
            _metricTile('إجمالي المصروفات', '${(_metrics['expenses_total'] ?? 0).toStringAsFixed(0)} ر.ي', Colors.purple),
          ],
        ),
      ],
    );
  }

  Widget _metricTile(String label, String value, Color color) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(label, style: const TextStyle(fontSize: 11, color: Colors.black54, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text(value, style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: color)),
          ],
        ),
      ),
    );
  }

  // 2. الجرد السريع الثابت بالكيبورد
  Widget _buildFastInventoryWorkstation() {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(10),
          color: Colors.white,
          child: Column(
            children: [
              Autocomplete<Map<String, dynamic>>(
                optionsBuilder: (TextEditingValue val) {
                  final q = val.text.trim().toLowerCase();
                  if (q.isEmpty) return const Iterable<Map<String, dynamic>>.empty();
                  return _products.where((p) =>
                      (p['name'] as String).toLowerCase().contains(q) ||
                      (p['barcode']?.toString() ?? '').contains(q));
                },
                displayStringForOption: (p) => p['name'] as String,
                onSelected: (p) {
                  _invNameCtrl.text = p['name'] as String;
                  _invPackTypeCtrl.text = p['pack_type'] as String;
                  _invUnitsPerPackCtrl.text = '${p['units_per_pack']}';
                  _invPackPriceCtrl.text = '${p['pack_buy_price']}';
                  _selectedPriceStatus = 'needs_review';
                  _qtyFocusNode.requestFocus();
                },
                fieldViewBuilder: (ctx, ctrl, focus, onSubmit) {
                  return TextField(
                    controller: ctrl,
                    focusNode: focus,
                    textInputAction: TextInputAction.next,
                    onChanged: (v) => _invNameCtrl.text = v,
                    onSubmitted: (_) => _qtyFocusNode.requestFocus(),
                    decoration: const InputDecoration(
                      labelText: '1. اسم الصنف أو الباركود (Enter للانتقال للكمية)',
                      isDense: true,
                      border: OutlineInputBorder(),
                    ),
                  );
                },
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _invPackCountCtrl,
                      focusNode: _qtyFocusNode,
                      keyboardType: TextInputType.number,
                      textInputAction: TextInputAction.done,
                      onSubmitted: (_) => _quickAddInventoryItem(),
                      decoration: const InputDecoration(labelText: '2. عدد العبوات (Enter للحفظ)', isDense: true, border: OutlineInputBorder()),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Expanded(
                    child: TextField(
                      controller: _invPackPriceCtrl,
                      keyboardType: TextInputType.number,
                      onSubmitted: (_) => _quickAddInventoryItem(),
                      decoration: const InputDecoration(labelText: 'سعر العبوة (للمراجعة)', isDense: true, border: OutlineInputBorder()),
                    ),
                  ),
                  const SizedBox(width: 6),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF0F766E), foregroundColor: Colors.white),
                    onPressed: _quickAddInventoryItem,
                    child: const Text('+ حفظ ↵'),
                  ),
                ],
              ),
            ],
          ),
        ),
        const Divider(height: 1),
        Expanded(
          child: ListView.separated(
            itemCount: _activeInventoryItems.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (ctx, i) {
              final it = _activeInventoryItems[i];
              final m = AppDatabase.calculateRowMetrics(it);
              return ListTile(
                dense: true,
                title: Text('${i + 1}. ${it['product_name']}', style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('الكمية: ${it['pack_count']} ${it['pack_type']} (${m['total_units']} وحدة) • السعر: ${it['pack_buy_price']} ر.ي'),
                trailing: Text('${m['total_value']} ر.ي (${it['price_status'] == 'confirmed' ? 'مؤكد' : 'للمراجعة'})',
                    style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF0F766E))),
              );
            },
          ),
        ),
      ],
    );
  }

  // 3. قاعدة الأصناف المشتركة
  Widget _buildProductsCatalogView() {
    final nameCtrl = TextEditingController();
    final packCtrl = TextEditingController(text: 'كرتون');
    final unitsCtrl = TextEditingController(text: '12');
    final priceCtrl = TextEditingController(text: '0');

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(10),
          child: Row(
            children: [
              Expanded(child: TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'اسم الصنف الجديد', isDense: true, border: OutlineInputBorder()))),
              const SizedBox(width: 6),
              Expanded(child: TextField(controller: priceCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'سعر العبوة', isDense: true, border: OutlineInputBorder()))),
              const SizedBox(width: 6),
              ElevatedButton(
                onPressed: () async {
                  if (nameCtrl.text.trim().isEmpty) return;
                  final db = await AppDatabase.instance.database;
                  final p = double.tryParse(priceCtrl.text) ?? 0;
                  final u = int.tryParse(unitsCtrl.text) ?? 12;
                  await db.insert('products', {
                    'name': nameCtrl.text.trim(),
                    'pack_type': packCtrl.text.trim(),
                    'base_unit': 'وحدة',
                    'units_per_pack': u,
                    'pack_buy_price': p,
                    'unit_buy_price': u > 0 ? p / u : 0,
                  });
                  _reloadAllData();
                },
                child: const Text('+ إضافة'),
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView.builder(
            itemCount: _products.length,
            itemBuilder: (ctx, i) {
              final p = _products[i];
              return ListTile(
                title: Text('${p['name']}', style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('العبوة: ${p['pack_type']} (${p['units_per_pack']} وحدات)'),
                trailing: Text('${p['pack_buy_price']} ر.ي', style: const TextStyle(fontWeight: FontWeight.bold)),
              );
            },
          ),
        ),
      ],
    );
  }

  // 4. الأصناف غير المسعرة / للمراجعة
  Widget _buildUnpricedReviewView() {
    return Column(
      children: [
        if (_unpricedItems.isNotEmpty)
          Padding(
            padding: const EdgeInsets.all(10),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green.shade700, foregroundColor: Colors.white),
                onPressed: () async {
                  final db = await AppDatabase.instance.database;
                  for (final it in _unpricedItems) {
                    if (((it['pack_buy_price'] as num?)?.toDouble() ?? 0) > 0) {
                      await db.update('inventory_items', {'price_status': 'confirmed'}, where: 'id = ?', whereArgs: [it['id']]);
                    }
                  }
                  _reloadAllData();
                },
                icon: const Icon(Icons.done_all),
                label: Text('اعتماد وتأكيد جميع الأصناف المسعرة دفعة واحدة (${_unpricedItems.length})'),
              ),
            ),
          ),
        Expanded(
          child: ListView.builder(
            itemCount: _unpricedItems.length,
            itemBuilder: (ctx, i) {
              final it = _unpricedItems[i];
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                child: ListTile(
                  title: Text('${it['product_name']}', style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text('الكمية: ${it['pack_count']} ${it['pack_type']} • السعر: ${it['pack_buy_price']} ر.ي'),
                  trailing: ElevatedButton(
                    onPressed: () async {
                      final db = await AppDatabase.instance.database;
                      await db.update('inventory_items', {'price_status': 'confirmed'}, where: 'id = ?', whereArgs: [it['id']]);
                      _reloadAllData();
                    },
                    child: const Text('✓ تأكيد'),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  // 5 & 6. ديون العملاء وديون المتجر للموردين
  Widget _buildPartiesDebtView({required bool isCustomer}) {
    final list = isCustomer ? _customers : _suppliers;
    final nameCtrl = TextEditingController();
    final debtCtrl = TextEditingController();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(10),
          child: Row(
            children: [
              Expanded(child: TextField(controller: nameCtrl, decoration: InputDecoration(labelText: isCustomer ? 'اسم العميل' : 'اسم المورد', isDense: true, border: const OutlineInputBorder()))),
              const SizedBox(width: 6),
              Expanded(child: TextField(controller: debtCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'مبلغ الدين (ر.ي)', isDense: true, border: OutlineInputBorder()))),
              const SizedBox(width: 6),
              ElevatedButton(
                onPressed: () async {
                  if (nameCtrl.text.trim().isEmpty) return;
                  final db = await AppDatabase.instance.database;
                  final pId = await db.insert(isCustomer ? 'customers' : 'suppliers', {
                    'branch_id': _targetBranch,
                    'name': nameCtrl.text.trim(),
                  });
                  final amt = double.tryParse(debtCtrl.text) ?? 0;
                  if (amt > 0) {
                    await db.insert(isCustomer ? 'customer_transactions' : 'supplier_transactions', {
                      isCustomer ? 'customer_id' : 'supplier_id': pId,
                      'tx_type': 'debt',
                      'amount': amt,
                      'tx_date': DateTime.now().toIso8601String().substring(0, 10),
                      'notes': 'رصيد أولي',
                    });
                  }
                  _reloadAllData();
                },
                child: const Text('+ حفظ'),
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView.builder(
            itemCount: list.length,
            itemBuilder: (ctx, i) {
              final p = list[i];
              final rem = ((p['total_debt'] as num?)?.toDouble() ?? 0) - ((p['total_paid'] as num?)?.toDouble() ?? 0);
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                child: ListTile(
                  title: Text('${p['name']}', style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text('الإجمالي: ${p['total_debt']} | المسدد: ${p['total_paid']} ر.ي'),
                  trailing: Text('المتبقي: ${rem.toStringAsFixed(0)} ر.ي',
                      style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.red)),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  // 7. السحبيات
  Widget _buildWithdrawalsView() {
    final personCtrl = TextEditingController();
    final amtCtrl = TextEditingController();
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(10),
          child: Row(
            children: [
              Expanded(child: TextField(controller: personCtrl, decoration: const InputDecoration(labelText: 'الشخص الساحب', isDense: true, border: OutlineInputBorder()))),
              const SizedBox(width: 6),
              Expanded(child: TextField(controller: amtCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'المبلغ (ر.ي)', isDense: true, border: OutlineInputBorder()))),
              const SizedBox(width: 6),
              ElevatedButton(
                onPressed: () async {
                  final amt = double.tryParse(amtCtrl.text) ?? 0;
                  if (amt <= 0 || personCtrl.text.trim().isEmpty) return;
                  final db = await AppDatabase.instance.database;
                  await db.insert('withdrawals', {
                    'branch_id': _targetBranch,
                    'amount': amt,
                    'w_date': DateTime.now().toIso8601String().substring(0, 10),
                    'person': personCtrl.text.trim(),
                    'reason': 'سحب عام',
                    'method': 'نقداً',
                  });
                  _reloadAllData();
                },
                child: const Text('+ سحب'),
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView.builder(
            itemCount: _withdrawals.length,
            itemBuilder: (ctx, i) {
              final w = _withdrawals[i];
              return ListTile(
                title: Text('${w['person']} — ${w['amount']} ر.ي', style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('${w['w_date']} • ${w['reason']}'),
              );
            },
          ),
        ),
      ],
    );
  }

  // 8. المصروفات التشغيلية
  Widget _buildExpensesView() {
    final descCtrl = TextEditingController();
    final amtCtrl = TextEditingController();
    String selectedCat = expenseCategories.first;

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(10),
          child: Row(
            children: [
              Expanded(child: TextField(controller: descCtrl, decoration: const InputDecoration(labelText: 'بيان المصروف', isDense: true, border: OutlineInputBorder()))),
              const SizedBox(width: 6),
              Expanded(child: TextField(controller: amtCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'المبلغ (ر.ي)', isDense: true, border: OutlineInputBorder()))),
              const SizedBox(width: 6),
              ElevatedButton(
                onPressed: () async {
                  final amt = double.tryParse(amtCtrl.text) ?? 0;
                  if (amt <= 0) return;
                  final db = await AppDatabase.instance.database;
                  await db.insert('expenses', {
                    'branch_id': _targetBranch,
                    'category': selectedCat,
                    'amount': amt,
                    'exp_date': DateTime.now().toIso8601String().substring(0, 10),
                    'description': descCtrl.text.trim().isEmpty ? selectedCat : descCtrl.text.trim(),
                  });
                  _reloadAllData();
                },
                child: const Text('+ مصروف'),
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView.builder(
            itemCount: _expenses.length,
            itemBuilder: (ctx, i) {
              final e = _expenses[i];
              return ListTile(
                title: Text('${e['category']}: ${e['amount']} ر.ي', style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('${e['exp_date']} • ${e['description']}'),
              );
            },
          ),
        ),
      ],
    );
  }

  // 9. التقارير الشاملة وحساب الضمار وسجل العمليات
  Widget _buildDhamarAndReportsView() {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('بيان حساب الضمار الموجود حالياً (بعد كل الإضافات والخصميات)',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                const Divider(),
                _dhamarLine('+ قيمة البضاعة في الجرد', _metrics['inventory_value'] ?? 0, Colors.teal),
                _dhamarLine('+ النقدية المسجلة بالصندوق', _metrics['registered_cash'] ?? 0, Colors.blue),
                _dhamarLine('+ ديون العملاء المتبقية (لنا)', _metrics['customer_debts'] ?? 0, Colors.green),
                const Divider(),
                _dhamarLine('= إجمالي الإضافات (الموجودات)', _metrics['total_additions'] ?? 0, Colors.teal.shade900, isBold: true),
                const Divider(),
                _dhamarLine('- ديون المتجر للموردين (علينا)', _metrics['supplier_debts'] ?? 0, Colors.red),
                _dhamarLine('- إجمالي السحبيات', _metrics['withdrawals_total'] ?? 0, Colors.orange.shade900),
                _dhamarLine('- إجمالي المصروفات التشغيلية', _metrics['expenses_total'] ?? 0, Colors.purple),
                const Divider(),
                _dhamarLine('= صافي الضمار النهائي حالياً', _metrics['net_dhamar'] ?? 0, const Color(0xFF0F172A), isBold: true),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        ElevatedButton.icon(
          onPressed: _exportCurrentInventoryPdf,
          icon: const Icon(Icons.print),
          label: const Text('طباعة / مشاركة تقرير الجرد الشامل وحساب الضمار (PDF A4)'),
        ),
      ],
    );
  }

  Widget _dhamarLine(String title, num val, Color color, {bool isBold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title, style: TextStyle(fontWeight: isBold ? FontWeight.bold : FontWeight.normal, fontSize: isBold ? 14 : 12)),
          Text('${val.toStringAsFixed(0)} ر.ي', style: TextStyle(fontWeight: FontWeight.bold, fontSize: isBold ? 15 : 13, color: color)),
        ],
      ),
    );
  }

  // 10. الإعدادات والنسخ الاحتياطي
  Widget _buildSettingsAndBackupView() {
    final cashCtrl = TextEditingController(text: '${_metrics['registered_cash'] ?? 0}');
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('تحديث النقدية المسجلة للفرع الحالي (تدخل في حساب الضمار)', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                TextField(controller: cashCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'النقدية المسجلة (ر.ي)', border: OutlineInputBorder())),
                const SizedBox(height: 8),
                ElevatedButton(
                  onPressed: () async {
                    final db = await AppDatabase.instance.database;
                    await db.update('branches', {'registered_cash': double.tryParse(cashCtrl.text) ?? 0}, where: 'id = ?', whereArgs: [_targetBranch]);
                    _reloadAllData();
                  },
                  child: const Text('حفظ النقدية'),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        ElevatedButton.icon(
          onPressed: () async {
            final jsonStr = await AppDatabase.instance.exportFullBackupJson();
            final dir = await getTemporaryDirectory();
            final file = File('${dir.path}/AL_SHEHAB_Backup.json');
            await file.writeAsString(jsonStr);
            await Share.shareXFiles([XFile(file.path)], text: 'نسخة احتياطية كاملة لتطبيق الشهاب');
          },
          icon: const Icon(Icons.backup),
          label: const Text('تصدير ومشاركة نسخة احتياطية كاملة من قاعدة البيانات'),
        ),
      ],
    );
  }
}
