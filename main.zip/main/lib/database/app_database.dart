import 'dart:convert';
import 'dart:io';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  static final AppDatabase instance = AppDatabase._init();
  static Database? _database;

  AppDatabase._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('al_shehab_store.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);
    return await openDatabase(
      path,
      version: 1,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: _createDB,
    );
  }

  Future<void> _createDB(Database db, int version) async {
    // 1. جدول الفرعين والأرصدة المالية المستقلة لكل فرع
    await db.execute('''
      CREATE TABLE branches (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        opening_capital REAL NOT NULL DEFAULT 0,
        capital_additions REAL NOT NULL DEFAULT 0,
        registered_cash REAL NOT NULL DEFAULT 0,
        other_liabilities REAL NOT NULL DEFAULT 0
      )
    ''');

    // إدراج الفرعين المستقلين افتراضياً
    await db.insert('branches', {
      'id': 'branch1',
      'name': 'الفرع الأول',
      'opening_capital': 0.0,
      'capital_additions': 0.0,
      'registered_cash': 0.0,
      'other_liabilities': 0.0,
    });
    await db.insert('branches', {
      'id': 'branch2',
      'name': 'الفرع الثاني',
      'opening_capital': 0.0,
      'capital_additions': 0.0,
      'registered_cash': 0.0,
      'other_liabilities': 0.0,
    });

    // 2. قاعدة بيانات الأصناف المشتركة بين الفرعين
    await db.execute('''
      CREATE TABLE products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        barcode TEXT,
        pack_type TEXT NOT NULL,
        base_unit TEXT NOT NULL,
        units_per_pack INTEGER NOT NULL DEFAULT 1,
        unit_buy_price REAL NOT NULL DEFAULT 0,
        pack_buy_price REAL NOT NULL DEFAULT 0,
        notes TEXT
      )
    ''');

    // 3. جدول الجرود (مستقل لكل فرع)
    await db.execute('''
      CREATE TABLE inventories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        branch_id TEXT NOT NULL,
        name TEXT NOT NULL,
        inv_date TEXT NOT NULL,
        notes TEXT,
        status TEXT NOT NULL DEFAULT 'open', -- open | approved | exception_approved
        FOREIGN KEY (branch_id) REFERENCES branches (id)
      )
    ''');

    // 4. جدول تفاصيل أصناف الجرد (11 حقلاً مع حفظ الأسعار مستقلة عن الجرود الأخرى)
    await db.execute('''
      CREATE TABLE inventory_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        inventory_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        product_name TEXT NOT NULL,
        barcode TEXT,
        pack_type TEXT NOT NULL,
        pack_count REAL NOT NULL DEFAULT 0,
        single_units REAL NOT NULL DEFAULT 0,
        units_per_pack INTEGER NOT NULL DEFAULT 1,
        pricing_basis TEXT NOT NULL DEFAULT 'pack', -- pack | unit
        unit_buy_price REAL NOT NULL DEFAULT 0,
        pack_buy_price REAL NOT NULL DEFAULT 0,
        price_status TEXT NOT NULL DEFAULT 'unpriced', -- confirmed | needs_review | unpriced
        FOREIGN KEY (inventory_id) REFERENCES inventories (id) ON DELETE CASCADE
      )
    ''');

    // 5. جدول العملاء وحركات ديونهم
    await db.execute('''
      CREATE TABLE customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        branch_id TEXT NOT NULL,
        name TEXT NOT NULL,
        phone TEXT,
        address TEXT,
        notes TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE customer_transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER NOT NULL,
        tx_type TEXT NOT NULL, -- debt | payment
        amount REAL NOT NULL,
        tx_date TEXT NOT NULL,
        notes TEXT,
        FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE CASCADE
      )
    ''');

    // 6. جدول الموردين وحركات ديون المتجر
    await db.execute('''
      CREATE TABLE suppliers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        branch_id TEXT NOT NULL,
        name TEXT NOT NULL,
        phone TEXT,
        due_date TEXT,
        notes TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE supplier_transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        supplier_id INTEGER NOT NULL,
        tx_type TEXT NOT NULL, -- debt | payment
        amount REAL NOT NULL,
        tx_date TEXT NOT NULL,
        notes TEXT,
        FOREIGN KEY (supplier_id) REFERENCES suppliers (id) ON DELETE CASCADE
      )
    ''');

    // 7. جدول السحبيات
    await db.execute('''
      CREATE TABLE withdrawals (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        branch_id TEXT NOT NULL,
        amount REAL NOT NULL,
        w_date TEXT NOT NULL,
        person TEXT NOT NULL,
        reason TEXT NOT NULL,
        method TEXT NOT NULL,
        notes TEXT
      )
    ''');

    // 8. جدول المصروفات التشغيلية
    await db.execute('''
      CREATE TABLE expenses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        branch_id TEXT NOT NULL,
        category TEXT NOT NULL,
        amount REAL NOT NULL,
        exp_date TEXT NOT NULL,
        description TEXT NOT NULL,
        notes TEXT
      )
    ''');

    // 9. جدول سجل العمليات الرقابي
    await db.execute('''
      CREATE TABLE audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        branch_id TEXT NOT NULL,
        action_type TEXT NOT NULL,
        details TEXT NOT NULL,
        created_at TEXT NOT NULL
      )
    ''');
  }

  // معادلة حساب سطر الجرد مع منع احتساب السعر مرتين
  static Map<String, double> calculateRowMetrics(Map<String, dynamic> item) {
    final double packCount = (item['pack_count'] as num?)?.toDouble() ?? 0.0;
    final double singleUnits = (item['single_units'] as num?)?.toDouble() ?? 0.0;
    final int unitsPerPack = ((item['units_per_pack'] as num?)?.toInt() ?? 1).clamp(1, 1000000);
    final double totalUnits = (packCount * unitsPerPack) + singleUnits;

    final double unitPrice = (item['unit_buy_price'] as num?)?.toDouble() ?? 0.0;
    final double packPrice = (item['pack_buy_price'] as num?)?.toDouble() ?? 0.0;
    final String basis = (item['pricing_basis'] as String?) ?? 'pack';
    final String status = (item['price_status'] as String?) ?? 'unpriced';

    double totalValue = 0.0;
    if (status == 'unpriced' && unitPrice == 0 && packPrice == 0) {
      totalValue = 0.0;
    } else if (basis == 'unit') {
      final double effUnit = unitPrice > 0 ? unitPrice : (packPrice / unitsPerPack);
      totalValue = totalUnits * effUnit;
    } else {
      final double effPack = packPrice > 0 ? packPrice : (unitPrice * unitsPerPack);
      totalValue = (packCount * effPack) + (singleUnits * (effPack / unitsPerPack));
    }

    return {
      'total_units': totalUnits,
      'total_value': double.parse(totalValue.toStringAsFixed(2)),
    };
  }

  Future<void> logAction(String branchId, String actionType, String details) async {
    final db = await instance.database;
    await db.insert('audit_logs', {
      'branch_id': branchId,
      'action_type': actionType,
      'details': details,
      'created_at': DateTime.now().toIso8601String().substring(0, 16).replaceAll('T', ' '),
    });
  }

  // تصدير قاعدة البيانات كاملة إلى JSON للنسخ الاحتياطي ونقلها لهاتف جديد
  Future<String> exportFullBackupJson() async {
    final db = await instance.database;
    final tables = [
      'branches',
      'products',
      'inventories',
      'inventory_items',
      'customers',
      'customer_transactions',
      'suppliers',
      'supplier_transactions',
      'withdrawals',
      'expenses',
      'audit_logs'
    ];
    final Map<String, dynamic> dump = {
      'signature': 'AL_SHEHAB_SQLITE_BACKUP_V1',
      'exported_at': DateTime.now().toIso8601String(),
      'tables': {},
    };
    for (final t in tables) {
      dump['tables'][t] = await db.query(t);
    }
    return const JsonEncoder.withIndent('  ').convert(dump);
  }

  // التحقق من سلامة النسخة واستعادتها داخل Transaction واحدة آمنة
  Future<bool> restoreFromBackupJson(String jsonContent) async {
    final decoded = jsonDecode(jsonContent) as Map<String, dynamic>;
    if (decoded['signature'] != 'AL_SHEHAB_SQLITE_BACKUP_V1' || decoded['tables'] == null) {
      throw Exception('ملف النسخة الاحتياطية غير صالح أو تالف');
    }
    final tables = decoded['tables'] as Map<String, dynamic>;
    final db = await instance.database;
    await db.transaction((txn) async {
      for (final table in [
        'inventory_items',
        'inventories',
        'customer_transactions',
        'customers',
        'supplier_transactions',
        'suppliers',
        'withdrawals',
        'expenses',
        'audit_logs',
        'products',
        'branches'
      ]) {
        await txn.delete(table);
      }
      for (final entry in tables.entries) {
        final rows = entry.value as List<dynamic>;
        for (final row in rows) {
          await txn.insert(entry.key, Map<String, dynamic>.from(row as Map));
        }
      }
    });
    return true;
  }
}
