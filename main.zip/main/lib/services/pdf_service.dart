import 'dart:typed_data';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../database/app_database.dart';

enum InventorySortOrder { byPriceDesc, byEntryOrder, byArabicAlphabetical }
enum InventoryFilterScope { fullInventory, unpricedOnly, pricedOnly }

class PdfExportService {
  static Future<Uint8List> buildInventoryAndDhamarPdf({
    required String branchName,
    required String inventoryName,
    required String inventoryDate,
    required List<Map<String, dynamic>> rawItems,
    required InventorySortOrder sortOrder,
    required InventoryFilterScope filterScope,
    required int itemsPerPage,
    required bool includeDhamarAppendix,
    required Map<String, dynamic> dhamarData,
    required pw.Font arabicFont,
  }) async {
    List<Map<String, dynamic>> items = rawItems.map((e) {
      final metrics = AppDatabase.calculateRowMetrics(e);
      return {
        ...e,
        'total_units': metrics['total_units'],
        'total_value': metrics['total_value'],
      };
    }).toList();

    if (filterScope == InventoryFilterScope.unpricedOnly) {
      items = items.where((x) => x['price_status'] != 'confirmed').toList();
    } else if (filterScope == InventoryFilterScope.pricedOnly) {
      items = items.where((x) => x['price_status'] == 'confirmed').toList();
    }

    if (sortOrder == InventorySortOrder.byPriceDesc) {
      items.sort((a, b) => ((b['total_value'] as num).compareTo(a['total_value'] as num)));
    } else if (sortOrder == InventorySortOrder.byArabicAlphabetical) {
      items.sort((a, b) => (a['product_name'] as String).compareTo(b['product_name'] as String));
    }

    final int chunkSize = itemsPerPage <= 0 ? 40 : itemsPerPage;
    final List<List<Map<String, dynamic>>> chunks = [];
    for (int i = 0; i < items.length; i += chunkSize) {
      chunks.add(items.sublist(
        i,
        i + chunkSize > items.length ? items.length : i + chunkSize,
      ));
    }
    if (chunks.isEmpty) chunks.add([]);

    final double grandTotal = items.fold(0.0, (sum, x) => sum + ((x['total_value'] as num?)?.toDouble() ?? 0.0));
    final doc = pw.Document();

    // 1. صفحات أصناف الجرد (40 صنفاً في كل صفحة A4 أو حسب اختيار المستخدم)
    for (int pageIndex = 0; pageIndex < chunks.length; pageIndex++) {
      final pageItems = chunks[pageIndex];
      final double pageSubtotal = pageItems.fold(0.0, (sum, x) => sum + ((x['total_value'] as num?)?.toDouble() ?? 0.0));
      final bool isLastPage = pageIndex == chunks.length - 1;

      doc.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.all(18),
          textDirection: pw.TextDirection.rtl,
          theme: pw.ThemeData.withFont(base: arabicFont, bold: arabicFont),
          build: (context) {
            return pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.stretch,
              children: [
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Text('متجر الشهاب - AL-SHEHAB Management', style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
                        pw.Text('الفرع: $branchName', style: const pw.TextStyle(fontSize: 9.5)),
                      ],
                    ),
                    pw.Column(
                      children: [
                        pw.Text(inventoryName, style: pw.TextStyle(fontSize: 11, fontWeight: pw.FontWeight.bold)),
                        pw.Text('تاريخ الجرد: $inventoryDate', style: const pw.TextStyle(fontSize: 9)),
                      ],
                    ),
                    pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.end,
                      children: [
                        pw.Text('صفحة ${pageIndex + 1} من ${chunks.length}', style: pw.TextStyle(fontSize: 9.5, fontWeight: pw.FontWeight.bold)),
                        pw.Text('العملة: ريال يمني (ر.ي)', style: const pw.TextStyle(fontSize: 8)),
                      ],
                    ),
                  ],
                ),
                pw.SizedBox(height: 6),
                pw.TableHelper.fromTextArray(
                  headers: ['م', 'اسم المنتج', 'الكمية', 'العبوة', 'سعر العبوة', 'إجمالي الصنف', 'حالة السعر'],
                  headerStyle: pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold, color: PdfColors.white),
                  headerDecoration: const pw.BoxDecoration(color: PdfColors.teal900),
                  cellStyle: pw.TextStyle(fontSize: chunkSize <= 25 ? 9.0 : 7.5),
                  cellPadding: const pw.EdgeInsets.symmetric(vertical: 2, horizontal: 4),
                  data: List.generate(pageItems.length, (idx) {
                    final it = pageItems[idx];
                    final statusLabel = it['price_status'] == 'confirmed'
                        ? 'مؤكد'
                        : it['price_status'] == 'needs_review'
                            ? 'للمراجعة'
                            : 'غير مسعر';
                    return [
                      '${pageIndex * chunkSize + idx + 1}',
                      '${it['product_name']}',
                      '${it['pack_count']} (${it['total_units']} وحدة)',
                      '${it['pack_type']} (${it['units_per_pack']})',
                      '${it['pack_buy_price']} ر.ي',
                      '${it['total_value']} ر.ي',
                      statusLabel,
                    ];
                  }),
                ),
                pw.Spacer(),
                pw.Divider(),
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Text('إجمالي قيمة الصفحة: ${pageSubtotal.toStringAsFixed(2)} ر.ي', style: pw.TextStyle(fontSize: 9.5, fontWeight: pw.FontWeight.bold)),
                    if (isLastPage)
                      pw.Text('الإجمالي النهائي لبضاعة الجرد: ${grandTotal.toStringAsFixed(2)} ر.ي', style: pw.TextStyle(fontSize: 10.5, fontWeight: pw.FontWeight.bold)),
                  ],
                ),
              ],
            );
          },
        ),
      );
    }

    // 2. صفحة الملحق الشامل لحساب الضمار الموجود حالياً بعد كل الإضافات والخصميات
    if (includeDhamarAppendix) {
      final double cash = (dhamarData['registered_cash'] as num?)?.toDouble() ?? 0.0;
      final double custDebts = (dhamarData['customer_debts'] as num?)?.toDouble() ?? 0.0;
      final double supDebts = (dhamarData['supplier_debts'] as num?)?.toDouble() ?? 0.0;
      final double otherLiab = (dhamarData['other_liabilities'] as num?)?.toDouble() ?? 0.0;
      final double withdrawals = (dhamarData['withdrawals_total'] as num?)?.toDouble() ?? 0.0;
      final double expenses = (dhamarData['expenses_total'] as num?)?.toDouble() ?? 0.0;

      final double totalAdditions = grandTotal + cash + custDebts;
      final double totalDeductions = supDebts + otherLiab + withdrawals + expenses;
      final double netDhamar = totalAdditions - totalDeductions;

      doc.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.all(20),
          textDirection: pw.TextDirection.rtl,
          theme: pw.ThemeData.withFont(base: arabicFont, bold: arabicFont),
          build: (context) {
            return pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.stretch,
              children: [
                pw.Text('متجر الشهاب — ملحق الحسابات الشامل وحساب الضمار الصافي ($branchName)',
                    style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold)),
                pw.SizedBox(height: 8),
                pw.TableHelper.fromTextArray(
                  headers: ['البند المحاسبي', 'الأثر', 'المبلغ (ر.ي)'],
                  headerStyle: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold, color: PdfColors.white),
                  headerDecoration: const pw.BoxDecoration(color: PdfColors.blueGrey900),
                  cellStyle: const pw.TextStyle(fontSize: 9),
                  data: [
                    ['1. إجمالي قيمة البضاعة في الجرد', '+ إضافة (أصل مخزني)', '${grandTotal.toStringAsFixed(2)} ر.ي'],
                    ['2. النقدية المسجلة بالصندوق والبنك', '+ إضافة (سيولة نقدية)', '${cash.toStringAsFixed(2)} ر.ي'],
                    ['3. إجمالي ديون العملاء المتبقية (لنا)', '+ إضافة (ذمم مدينة)', '${custDebts.toStringAsFixed(2)} ر.ي'],
                    ['إجمالي الإضافات (البضاعة + النقدية + ديون العملاء)', 'مجموع الإضافات', '${totalAdditions.toStringAsFixed(2)} ر.ي'],
                    ['4. إجمالي ديون الموردين المتبقية (علينا) + التزامات', '- خصم (التزامات)', '${(supDebts + otherLiab).toStringAsFixed(2)} ر.ي'],
                    ['5. إجمالي السحبيات المسجلة', '- خصم (مسحوبات)', '${withdrawals.toStringAsFixed(2)} ر.ي'],
                    ['6. إجمالي المصروفات التشغيلية', '- خصم (مصاريف)', '${expenses.toStringAsFixed(2)} ر.ي'],
                    ['إجمالي كافة الخصميات', 'مجموع الخصميات', '${totalDeductions.toStringAsFixed(2)} ر.ي'],
                    ['صافي الضمار الموجود حالياً بعد كل الإضافات والخصميات', 'الصافي النهائي', '${netDhamar.toStringAsFixed(2)} ر.ي'],
                  ],
                ),
              ],
            );
          },
        ),
      );
    }

    return doc.save();
  }
}
