@echo off
chcp 65001 >nul
echo ========================================================
echo   بناء ملف تطبيق الشهاب للأندرويد (AL-SHEHAB Release APK)
echo ========================================================
flutter create --platforms=android --org com.alshehab.management .
call flutter pub get
call flutter build apk --release --no-tree-shake-icons
echo.
echo تم بناء ملف APK بنجاح في المسار:
echo build\app\outputs\flutter-apk\app-release.apk
pause
