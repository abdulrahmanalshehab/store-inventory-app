@echo off
chcp 65001 >nul
title الشهاب لإدارة الجرد والحسابات - برنامج سطح المكتب
set APP_PATH=%~dp0web_apk_ready\index.html
start msedge --app="file:///%APP_PATH:\=/%" --window-size=1280,820 || start chrome --app="file:///%APP_PATH:\=/%" --window-size=1280,820 || start "" "%APP_PATH%"
